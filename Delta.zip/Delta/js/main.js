document.addEventListener('DOMContentLoaded', function() {
    // 1. Safe element selector with error handling
    function getElement(selector) {
        const el = document.querySelector(selector);
        if (!el) console.warn(`Element not found: ${selector}`);
        return el;
    }

    // 2. Preloader with double safety
    const loaderWrapper = getElement('.loader-wrapper');
    if (loaderWrapper) {
        let loaderRemoved = false;
        const removeLoader = () => {
            if (loaderRemoved) return;
            loaderRemoved = true;
            loaderWrapper.classList.add('fade-out');
            setTimeout(() => {
                loaderWrapper.style.display = 'none';
            }, 500);
        };

        window.addEventListener('load', removeLoader);
        setTimeout(removeLoader, 3000);
    }

    // 3. Mobile navigation with toggle lock
    const hamburger = getElement('.hamburger');
    const navLinks = getElement('.nav-links');
    let isAnimating = false;

    if (hamburger && navLinks) {
        const toggleMenu = () => {
            if (isAnimating) return;
            isAnimating = true;
            
            hamburger.classList.toggle('active');
            navLinks.classList.toggle('active');
            
            setTimeout(() => {
                isAnimating = false;
            }, 300);
        };

        hamburger.addEventListener('click', toggleMenu);
        
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', () => {
                if (hamburger.classList.contains('active')) {
                    toggleMenu();
                }
            });
        });
    }

    // 4. Sticky navbar
    const navbar = getElement('.navbar');
    if (navbar) {
        window.addEventListener('scroll', () => {
            navbar.classList.toggle('scrolled', window.scrollY > 50);
        });
    }

    // 5. Back to top button
    const backToTopBtn = getElement('.back-to-top');
    if (backToTopBtn) {
        window.addEventListener('scroll', () => {
            backToTopBtn.classList.toggle('active', window.scrollY > 300);
        });
        
        backToTopBtn.addEventListener('click', (e) => {
            e.preventDefault();
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }

    // 6. FAQ accordion
    const faqQuestions = document.querySelectorAll('.faq-question');
    faqQuestions.forEach(question => {
        question.addEventListener('click', function() {
            this.classList.toggle('active');
        });
    });

    // 7. Animated counters (optimized)
    const statNumbers = document.querySelectorAll('.stat-number');
    if (statNumbers.length > 0) {
        let animated = false;
        
        const animateCounters = () => {
            if (animated) return;
            animated = true;
            
            statNumbers.forEach(stat => {
                const target = +stat.dataset.count;
                const duration = 2000;
                const startTime = performance.now();
                
                const update = (currentTime) => {
                    const elapsed = currentTime - startTime;
                    if (elapsed > duration) {
                        stat.textContent = target.toLocaleString();
                        return;
                    }
                    
                    const progress = elapsed / duration;
                    const value = Math.floor(progress * target);
                    stat.textContent = value.toLocaleString();
                    
                    if (value < target) {
                        requestAnimationFrame(update);
                    }
                };
                
                requestAnimationFrame(update);
            });
        };
        
        const observer = new IntersectionObserver((entries) => {
            if (entries[0].isIntersecting) {
                animateCounters();
                observer.disconnect();
            }
        }, { threshold: 0.5 });
        
        observer.observe(statNumbers[0].closest('.stats'));
    }

    // 8. Smooth scrolling with offset
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                e.preventDefault();
                const headerHeight = document.querySelector('.navbar').offsetHeight;
                const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset - headerHeight;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });

    // 9. Download button demo
    const downloadBtn = getElement('.download-btn');
    if (downloadBtn) {
        downloadBtn.addEventListener('click', (e) => {
            e.preventDefault();
            alert('Download started! (Demo)');
        });
    }

    // 10. Ripple effect with cleanup
    document.querySelectorAll('.btn').forEach(button => {
        button.addEventListener('click', function(e) {
            const rect = this.getBoundingClientRect();
            const ripple = document.createElement('span');
            
            ripple.className = 'ripple';
            ripple.style.left = `${e.clientX - rect.left}px`;
            ripple.style.top = `${e.clientY - rect.top}px`;
            
            this.appendChild(ripple);
            
            setTimeout(() => {
                if (ripple.parentNode === this) {
                    this.removeChild(ripple);
                }
            }, 600);
        });
    });
});